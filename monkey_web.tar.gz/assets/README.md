# (m)onkey — Browser Version (pygbag)

This is your original pygame game, converted to run in a browser via **pygbag**.
Every game mechanic (gravity, jumping, collisions, scoring, cactus spawning,
foot-switch animation) is untouched — the only changes are the ones needed to
run in a browser.

## What changed and why

1. **`async def game_loop()` instead of `def game_loop()`**
   Browsers can't run a blocking `while True` loop — it would freeze the tab.
   pygbag needs your main loop to be an `async` function so it can hand
   control back to the browser every frame.

2. **`await asyncio.sleep(0)` at the end of the loop**
   This is the line that actually hands control back to the browser for a
   moment (to redraw, handle input, etc.) before running the next frame.
   It doesn't pause your game — `sleep(0)` just yields, it doesn't wait.

3. **`asyncio.run(game_loop())` instead of `game_loop()`**
   This is how you *start* an async function from regular code.

4. **Flattened asset paths**
   Your original code loaded files from `onkey_start/Assets/sprites/...` etc.
   pygbag serves whatever is in this folder directly to the browser, so all
   images/sounds/fonts now sit right next to `main.py` and are loaded by
   plain filename (e.g. `pygame.image.load('jump.png')`).

5. **Placeholder `horizon.png`**
   Your uploaded files didn't include the ground/background image
   (`Horizon.png`) that the code loads. I generated a simple placeholder
   strip so the game runs end-to-end. **Swap in your real `Horizon.png`**
   (same filename, lowercase `horizon.png`) to get your original look back.

Nothing else — physics, collision boxes, scoring, sounds, sprite logic — was
touched.

## How to run it in a browser

1. Install pygbag (one time):
   ```
   pip install pygbag
   ```

2. From inside this folder, run:
   ```
   python -m pygbag main.py
   ```

3. pygbag starts a local server and prints a URL like
   `http://localhost:8000` — open that in your browser and the game will
   load and run there.

4. To publish it (e.g. to itch.io like your other game), run:
   ```
   python -m pygbag --build .
   ```
   This creates a `build/web` folder — zip its contents and upload that as
   an HTML5 game.

## Notes for browser quirks

- **Sound**: pygbag auto-converts your `.wav` files to `.ogg` during build
  (browsers don't universally support `.wav`) — you don't need to do
  anything, it happens automatically and your code keeps referencing the
  original `.wav` filenames.
- **Audio autoplay**: browsers block audio until the user interacts with the
  page. Your game already requires pressing `E` to start, so this isn't an
  issue — audio will work fine once the player presses a key.
